<div class="post_text">
    <div class="post_text_inner">
        <span class="icon_link icon" aria-hidden="true"></span>
        <h5 itemprop="name" class="entry_title"><a itemprop="url" href="<?php the_permalink(); ?>" target="_self" title="<?php the_title_attribute(); ?>"><span><?php the_title(); ?></span></a></h5>
    </div>
</div>